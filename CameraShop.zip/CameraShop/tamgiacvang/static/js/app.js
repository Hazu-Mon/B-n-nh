const products=[{id:1,name:'Canon EOS R50',type:'camera',price:15900000,img:'camera'},
    {id:2,name:'Sony Alpha A6400',type:'camera',price:18500000,img:'about'},
    {id:3,name:'Ống kính zoom 24–70 mm',type:'lens',price:12900000,img:'lens'},
    {id:4,name:'Bộ đèn studio',type:'studio',price:3500000,img:'studio'},
    {id:5,name:'Canon EOS R50 – bộ cơ bản',type:'camera',price:17900000,img:'camera'},
    {id:6,name:'Ống kính chân dung',type:'lens',price:6500000,img:'lens'},
    {id:7,name:'Bộ ánh sáng chụp sản phẩm',type:'studio',price:4200000,img:'studio'},
    {id:8,name:'Sony Alpha – bộ du lịch',type:'camera',price:20900000,img:'about'}];
    const money=n=>n.toLocaleString('vi-VN')+' ₫';
    let cart=[];try(const x=JSON.parse(localStorage.getItem('camera-demo-cart')||'[]'));
        if(Array.isArray(x))cart=x.filter(i=>products.some(p=>p.id===i.id)&&Number.isInteger(i.qty)&&i.qty>0)catch{}let filter='all';
        const asset=document.body.dataset.imageBase||'static/images/';
        const card=(p,rental=false)=>`<article class="card"><span class="tag">${rental?'CHO THUÊ':'MẪU'}</span>
        <img src="${asset+p.img}.jpg" alt="${p.name}">
        <h3>${p.name}</h3>
        <p class="muted">Hình và giá minh họa</p>
        <div class="card-bottom">
        <span class="price">${rental?'Liên hệ giá thuê':money(p.price)}</span>
        ${rental?'<a href="#rental" class="btn">Chọn</a>':`<button data-add="${p.id}" aria-label="Thêm ${p.name} vào giỏ">＋</button>`}</div>
        </article>`;function render(){const q=document.querySelector('#search').value.toLowerCase()};const list=products.filter(p=>(filter==='all'||p.type===filter)&&p.name.toLowerCase().includes(q));document.querySelector('#catalog')
            .innerHTML=list.map(p=>card(p))
            .join('');
            document.querySelector('#no-results').hidden=!!list.length;
            document.querySelector('#featured').innerHTML=products.slice(0,4).map(p=>card(p)).join('');
            document.querySelector('#rentals').innerHTML=products.filter(p=>p.type==='camera').slice(0,4).map(p=>card(p,true)).join('');
            render();
            document.querySelector('#search').addEventListener('input',render);
            document.querySelector('#filters').addEventListener('click',e=>{
                if(!e.target.dataset.filter)return;
                filter=e.target.dataset.filter;
                document.querySelectorAll('[data-filter]').forEach(b=>b.classList.toggle('active',b===e.target));
                render()
            });
            function notice(s){
                document.querySelector('#message-text').textContent=s;
                document.querySelector('#message').showModal()
            }
            document.querySelector('#close-dialog').onclick=()=>document.querySelector('#message').close();
            function updateCart(){
                try{
                    localStorage.setItem('camera-demo-cart',JSON.stringify(cart))
                }catch{}
                document.querySelector('#count').textContent=cart.reduce((s,i)=>s+i.qty,0);
                document.querySelector('#cart-items').innerHTML=cart.length?cart.map(i=>{
                    const p=products.find(p=>p.id===i.id);
                    return `<div class="cart-row"><span>${p.name} × ${i.qty}</span><span>${money(p.price*i.qty)} <button data-remove="${i.id}">Xóa</button></span></div>`
                }).join(''):'<p class="empty">Giỏ hàng chưa có sản phẩm.</p>';
                document.querySelector('#total').textContent='Tổng: '+money(cart.reduce((s,i)=>s+products.find(p=>p.id===i.id).price*i.qty,0))
            }
            document.addEventListener('click',e=>{
                if(e.target.dataset.add){
                    const id=Number(e.target.dataset.add),
                        item=cart.find(i=>i.id===id);
                    if(item)
                        item.qty++;
                    else
                        cart.push({id,qty:1});
                    updateCart();
                    notice('Đã thêm vào giỏ hàng demo.')
                }
                if(e.target.dataset.remove){
                    cart=cart.filter(i=>i.id!==Number(e.target.dataset.remove));
                    updateCart()
                }
            });
            document.querySelector('#checkout').onclick=()=>notice(cart.length?'Đây là xác nhận minh họa. Chưa có đơn hàng hoặc thanh toán thật.':'Bạn chưa chọn sản phẩm.');
            document.querySelectorAll('.demo-form').forEach(f=>f.addEventListener('submit',e=>{
                e.preventDefault();
                const a=f.elements.start,
                    b=f.elements.end;
                if(a&&b&&b.value<=a.value){
                    notice('Ngày trả phải sau ngày nhận.');
                    return
                }
                notice('Thông tin biểu mẫu hợp lệ. Đây là demo giao diện; chưa gửi đơn lên máy chủ.')
            }));
            function route(){
                const id=location.hash.slice(1)||'home';
                document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===id));
                if(!document.querySelector('.page.active'))
                    document.querySelector('#home').classList.add('active');
                window.scrollTo(0,0)
            }
            window.addEventListener('hashchange',route);
            route();
            updateCart();